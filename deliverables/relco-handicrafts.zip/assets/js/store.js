/* RELCO Handicrafts store behaviour */
(function () {
  "use strict";

  var CART_KEY = "relco-handicrafts-cart-v1";
  var currency = "USD";

  function money(value) {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currency,
      maximumFractionDigits: 0
    }).format(value);
  }

  function readCart() {
    try {
      var raw = localStorage.getItem(CART_KEY);
      var parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      return [];
    }
  }

  function writeCart(items) {
    try {
      localStorage.setItem(CART_KEY, JSON.stringify(items));
    } catch (error) {
      /* storage may be unavailable in private mode */
    }
  }

  var cart = readCart();

  function cartCount() {
    return cart.reduce(function (total, item) {
      return total + item.qty;
    }, 0);
  }

  function cartSubtotal() {
    return cart.reduce(function (total, item) {
      return total + item.qty * item.price;
    }, 0);
  }

  function updateBadges() {
    var count = cartCount();
    document.querySelectorAll("[data-cart-count]").forEach(function (node) {
      node.textContent = count;
    });
    document.querySelectorAll("[data-cart-total]").forEach(function (node) {
      node.textContent = money(cartSubtotal());
    });
  }

  function renderDrawer() {
    var body = document.querySelector("[data-cart-items]");
    if (!body) return;

    if (!cart.length) {
      body.innerHTML =
        '<div class="cart-empty"><p>Your basket is empty.</p><p style="margin-top:8px"><a class="link-underline" href="shop.html">Browse the collection</a></p></div>';
    } else {
      body.innerHTML = cart
        .map(function (item, index) {
          return (
            '<div class="cart-item">' +
            '<img src="' + item.img + '" alt="' + item.name + '" width="76" height="92" loading="lazy">' +
            '<div>' +
            '<div class="cart-meta">' + item.category + "</div>" +
            "<h3>" + item.name + "</h3>" +
            '<div class="cart-price">' + money(item.price) + "</div>" +
            '<div class="cart-item-controls">' +
            '<button type="button" data-cart-minus="' + index + '" aria-label="Decrease quantity">-</button>' +
            "<span>" + item.qty + "</span>" +
            '<button type="button" data-cart-plus="' + index + '" aria-label="Increase quantity">+</button>' +
            "</div>" +
            "</div>" +
            '<button type="button" class="cart-remove" data-cart-remove="' + index + '">Remove</button>' +
            "</div>"
          );
        })
        .join("");
    }

    updateBadges();
    renderCheckoutSummary();
  }

  function save() {
    writeCart(cart);
    renderDrawer();
  }

  function addItem(data, qty) {
    var quantity = Math.max(1, parseInt(qty, 10) || 1);
    var found = cart.find(function (item) {
      return item.sku === data.sku;
    });
    if (found) {
      found.qty += quantity;
    } else {
      cart.push({
        sku: data.sku,
        name: data.name,
        price: Number(data.price),
        category: data.category || "Handicraft",
        img: data.img,
        qty: quantity
      });
    }
    save();
    openDrawer();
  }

  function openDrawer() {
    var drawer = document.querySelector("[data-cart-drawer]");
    var overlay = document.querySelector("[data-cart-overlay]");
    if (!drawer) return;
    drawer.classList.add("is-open");
    drawer.setAttribute("aria-hidden", "false");
    if (overlay) overlay.classList.add("is-open");
    document.body.classList.add("is-locked");
  }

  function closeDrawer() {
    var drawer = document.querySelector("[data-cart-drawer]");
    var overlay = document.querySelector("[data-cart-overlay]");
    if (!drawer) return;
    drawer.classList.remove("is-open");
    drawer.setAttribute("aria-hidden", "true");
    if (overlay) overlay.classList.remove("is-open");
    document.body.classList.remove("is-locked");
  }

  function renderCheckoutSummary() {
    var wrap = document.querySelector("[data-summary-items]");
    if (!wrap) return;

    if (!cart.length) {
      wrap.innerHTML =
        '<p style="font-size:0.86rem;color:var(--ink-soft)">No items yet. <a class="link-underline" href="shop.html">Browse the collection</a></p>';
    } else {
      wrap.innerHTML = cart
        .map(function (item) {
          return (
            '<div class="summary-item">' +
            '<img src="' + item.img + '" alt="' + item.name + '" width="54" height="66" loading="lazy">' +
            "<div><strong>" + item.name + "</strong><small>Qty " + item.qty + "</small></div>" +
            "<div>" + money(item.price * item.qty) + "</div>" +
            "</div>"
          );
        })
        .join("");
    }

    var subtotal = cartSubtotal();
    var shipping = cart.length ? 0 : 0;
    var nodes = document.querySelectorAll("[data-summary-subtotal]");
    nodes.forEach(function (node) {
      node.textContent = money(subtotal);
    });
    document.querySelectorAll("[data-summary-shipping]").forEach(function (node) {
      node.textContent = shipping === 0 ? "Included" : money(shipping);
    });
    document.querySelectorAll("[data-summary-total]").forEach(function (node) {
      node.textContent = money(subtotal + shipping);
    });
  }

  function bindCartControls() {
    document.addEventListener("click", function (event) {
      var add = event.target.closest("[data-add-to-cart]");
      if (add) {
        event.preventDefault();
        var quantity = add.dataset.qty || 1;
        var row = add.closest(".buy-row");
        if (row) {
          var input = row.querySelector("[data-qty] input");
          if (input) quantity = input.value;
        }
        addItem(add.dataset, quantity);
        return;
      }

      var plus = event.target.closest("[data-cart-plus]");
      if (plus) {
        var plusIndex = Number(plus.dataset.cartPlus);
        cart[plusIndex].qty += 1;
        save();
        return;
      }

      var minus = event.target.closest("[data-cart-minus]");
      if (minus) {
        var minusIndex = Number(minus.dataset.cartMinus);
        cart[minusIndex].qty -= 1;
        if (cart[minusIndex].qty <= 0) {
          cart.splice(minusIndex, 1);
        }
        save();
        return;
      }

      var remove = event.target.closest("[data-cart-remove]");
      if (remove) {
        cart.splice(Number(remove.dataset.cartRemove), 1);
        save();
        return;
      }

      if (event.target.closest("[data-cart-open]")) {
        event.preventDefault();
        openDrawer();
        return;
      }

      if (
        event.target.closest("[data-cart-close]") ||
        event.target.closest("[data-cart-overlay]")
      ) {
        closeDrawer();
      }
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") closeDrawer();
    });
  }

  function bindQuantity() {
    document.querySelectorAll("[data-qty]").forEach(function (control) {
      var input = control.querySelector("input");
      var decrease = control.querySelector("[data-qty-minus]");
      var increase = control.querySelector("[data-qty-plus]");
      if (decrease) {
        decrease.addEventListener("click", function () {
          input.value = Math.max(1, Number(input.value) - 1);
        });
      }
      if (increase) {
        increase.addEventListener("click", function () {
          input.value = Number(input.value) + 1;
        });
      }
    });
  }

  function bindGallery() {
    var main = document.querySelector("[data-gallery-main]");
    var thumbs = document.querySelectorAll("[data-gallery-thumb]");
    if (!main || !thumbs.length) return;

    thumbs.forEach(function (thumb) {
      thumb.addEventListener("click", function () {
        var image = thumb.querySelector("img");
        main.src = thumb.dataset.src;
        if (image) main.alt = image.alt;
        thumbs.forEach(function (other) {
          other.classList.remove("is-active");
        });
        thumb.classList.add("is-active");
      });
    });
  }

  function bindShop() {
    var grid = document.querySelector("[data-shop-grid]");
    if (!grid) return;

    var chips = document.querySelectorAll("[data-filter]");
    var sort = document.querySelector("[data-sort]");
    var count = document.querySelector("[data-result-count]");
    var cards = Array.prototype.slice.call(grid.children);
    var active = "all";

    function apply() {
      var visible = 0;
      cards.forEach(function (card) {
        var match = active === "all" || card.dataset.category === active;
        card.style.display = match ? "" : "none";
        if (match) visible += 1;
      });
      if (count) {
        count.textContent = visible + (visible === 1 ? " piece" : " pieces");
      }
    }

    chips.forEach(function (chip) {
      chip.addEventListener("click", function () {
        chips.forEach(function (other) {
          other.classList.remove("is-active");
          other.setAttribute("aria-pressed", "false");
        });
        chip.classList.add("is-active");
        chip.setAttribute("aria-pressed", "true");
        active = chip.dataset.filter;
        apply();
      });
    });

    if (sort) {
      sort.addEventListener("change", function () {
        var value = sort.value;
        var ordered = cards.slice();
        if (value === "price-asc") {
          ordered.sort(function (a, b) {
            return Number(a.dataset.price) - Number(b.dataset.price);
          });
        } else if (value === "price-desc") {
          ordered.sort(function (a, b) {
            return Number(b.dataset.price) - Number(a.dataset.price);
          });
        } else if (value === "name") {
          ordered.sort(function (a, b) {
            return a.dataset.name.localeCompare(b.dataset.name);
          });
        }
        ordered.forEach(function (card) {
          grid.appendChild(card);
        });
        apply();
      });
    }

    apply();
  }

  function bindChrome() {
    var header = document.querySelector("[data-header]");
    if (header) {
      var onScroll = function () {
        header.classList.toggle("is-stuck", window.scrollY > 8);
      };
      onScroll();
      window.addEventListener("scroll", onScroll, { passive: true });
    }

    var toggle = document.querySelector("[data-menu-toggle]");
    var nav = document.querySelector("[data-nav]");
    if (toggle && nav) {
      toggle.addEventListener("click", function () {
        var open = nav.classList.toggle("is-open");
        toggle.setAttribute("aria-expanded", open ? "true" : "false");
      });
    }

    var marquee = document.querySelector("[data-marquee]");
    if (marquee) {
      marquee.innerHTML = marquee.innerHTML + marquee.innerHTML;
    }

    var reveals = document.querySelectorAll("[data-reveal]");
    if ("IntersectionObserver" in window) {
      var observer = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              entry.target.classList.add("is-in");
              observer.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.12 }
      );
      reveals.forEach(function (node) {
        observer.observe(node);
      });
    } else {
      reveals.forEach(function (node) {
        node.classList.add("is-in");
      });
    }
  }

  function bindCheckout() {
    var form = document.querySelector("[data-order-form]");
    if (!form) return;

    renderCheckoutSummary();

    form.addEventListener("submit", function (event) {
      event.preventDefault();
      if (!cart.length) {
        window.location.href = "shop.html";
        return;
      }

      var data = new FormData(form);
      var reference =
        "RELCO-" +
        new Date().getFullYear() +
        "-" +
        String(Math.floor(Math.random() * 9000) + 1000);
      var lines = cart.map(function (item) {
        return item.qty + " x " + item.name + " (" + item.sku + ") at " + money(item.price);
      });

      var message = [
        "New handicrafts order",
        "Reference: " + reference,
        "",
        "Name: " + (data.get("name") || ""),
        "Email: " + (data.get("email") || ""),
        "Phone: " + (data.get("phone") || ""),
        "Country: " + (data.get("country") || ""),
        "Address: " + (data.get("address") || ""),
        "City: " + (data.get("city") || ""),
        "Postal code: " + (data.get("postal") || ""),
        "",
        "Items:",
        lines.join("\n"),
        "",
        "Subtotal: " + money(cartSubtotal()),
        "Payment method: " + (data.get("payment") || ""),
        "Notes: " + (data.get("notes") || "")
      ].join("\n");

      var mailto =
        "mailto:hello@raschident.com?subject=" +
        encodeURIComponent("Handicrafts order " + reference) +
        "&body=" +
        encodeURIComponent(message);

      var success = document.querySelector("[data-order-success]");
      var checkoutBody = document.querySelector("[data-checkout-body]");
      if (success && checkoutBody) {
        checkoutBody.hidden = true;
        success.hidden = false;
        var refNode = success.querySelector("[data-order-ref]");
        if (refNode) refNode.textContent = reference;
        var mailLink = success.querySelector("[data-order-mail]");
        if (mailLink) mailLink.href = mailto;
        success.scrollIntoView({ behavior: "smooth", block: "start" });
      }

      cart = [];
      save();
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    bindChrome();
    bindCartControls();
    bindQuantity();
    bindGallery();
    bindShop();
    bindCheckout();
    renderDrawer();
    updateBadges();
  });
})();
